#ifndef __RoleBridgeStart_H__
#define __RoleBridgeStart_H__

#include "Role.h"
class RoleBridgeStart :public Role
{
public:
	
};

#endif