
#ifndef __RoleMushroomAddLife_H__
#define __RoleMushroomAddLife_H__


#include "Role.h"

class RoleMushroomAddLife : public Role
{
public:
	virtual bool init(ValueMap& objProperty);
};


#endif
